<?php
   

    
    //echo "Hello from PHP";
    $input1 = $_GET['ip'];
    $input2 = $_GET['type'];
    $input3 = $_GET['lat'];
    $input4 = $_GET['long'];
    $input5 = $_GET['choice'];
    //echo "in Php";
    //echo $input1;
    //echo $input5;
    if($input5 == "usual")
    {
        //echo "In usual";
        if($input2 == "user" || $input2 == "page" || $input2 == "event" || $input2 == "group")
        {
    
        $url = "https://graph.facebook.com/v2.8/search?q=".$input1."&type=".$input2."&fields=".
        "id,name,picture.width(700).height(700)&access_token=".
"EAACJtDlQuJ4BAJQFX65RaeXvTCdbZCERg1HWubAKoyLN1klgguwc4fUFAr9qyF8miIkexCSnVibD0eh6FeqyF8Ha0AKZAf8kvbhcusQEfq1IBHgh2exyCrqXAOATwHzzcz7Hil1FubKZBT7AD8zMv75JunCtskZD";
    
        //echo $url;
        
        $d = file_get_contents($url);
        $e = json_decode($d, true);
        //$a = $e['data'];
        $myJSON = json_encode($e);
        echo $myJSON;
     
        }
    
        elseif($input2 == "place")
        {
        
        //echo "Selected place!";
        
        $url = "https://graph.facebook.com/v2.8/search?q=".$input1."&type=place&center=".$input3.",".$input4."&fields=".
        "id,name,picture.width(700).height(700)&access_token=".
"EAACJtDlQuJ4BAJQFX65RaeXvTCdbZCERg1HWubAKoyLN1klgguwc4fUFAr9qyF8miIkexCSnVibD0eh6FeqyF8Ha0AKZAf8kvbhcusQEfq1IBHgh2exyCrqXAOATwHzzcz7Hil1".
        "FubKZBT7AD8zMv75JunCtskZD";
        
        //echo $url;
        
        $d = file_get_contents($url);
        $e = json_decode($d, true);
        //$a = $e['data'];
        $myJSON = json_encode($e);
        echo $myJSON;
        }
    }
    else
    {
        $input6 = $_GET['id'];
        //echo $input6;
        //echo "Hello";
        /*
        $url = "https://graph.facebook.com/v2.8/".$input6."?fields=albums.limit(5){name,photos.limit(2){name,picture}},".
        "posts.limit(5){created_time}"."&access_token=".
        "EAACJtDlQuJ4BAJQFX65RaeXvTCdbZCERg1HWubAKoyLN1klgguwc4fUFAr9qyF8miIkexCSnVibD0eh6FeqyF8Ha0AKZAf8kvbhcusQEf".
        "q1IBHgh2exyCrqXAOATwHzzcz7Hil1FubKZBT7AD8zMv75JunCtskZD";
        */
        $d = file_get_contents("https://graph.facebook.com/v2.8/".$input6."?fields=albums.limit(5){name,photos.limit(2){name,picture,images}},".
                               "posts.limit(5){created_time,message,story}"."&access_token=".
                               "EAACJtDlQuJ4BAJQFX65RaeXvTCdbZCERg1HWubAKoyLN1klgguwc4fUFAr9qyF8miIkexCSnVibD0eh6FeqyF8Ha0AKZAf8kvbhcusQEf".
                               "q1IBHgh2exyCrqXAOATwHzzcz7Hil1FubKZBT7AD8zMv75JunCtskZD");
        $e = json_decode($d, true);
        
        //echo $e;
        //$a = $e['data'];
        $myJSON = json_encode($e);
        echo $myJSON;
            
    }
    
    
    
    
    
    
?>