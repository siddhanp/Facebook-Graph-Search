window.fbAsyncInit = function() {
    FB.init({
            appId      : '151407148710046',
            xfbml      : true,
            version    : 'v2.8'
            });
    FB.AppEvents.logPageView();
};

(function(d, s, id){
 var js, fjs = d.getElementsByTagName(s)[0];
 if (d.getElementById(id)) {return;}
 js = d.createElement(s); js.id = id;
 js.src = "//connect.facebook.net/en_US/sdk.js";
 fjs.parentNode.insertBefore(js, fjs);
 }(document, 'script', 'facebook-jssdk'));

$(document).ready(function(){
                  $("#searchBox").hover(function(){
                                        
                                         $(".form-control").tooltip('destroy');
                                         });
                  });

var currentTab="user";
var input;
var lat=0;
var long=0;

if (navigator.geolocation)
{
    navigator.geolocation.getCurrentPosition(function showPosition(position){
    lat = position.coords.latitude;
    long = position.coords.longitude;
    });
}

function letsGo(name,url,currentTab,id)
{
    //alert("inletsgo");
    if (localStorage.getItem(id) === null)
    {
        var newRow = name+","+url+","+currentTab;
        //alert(newRow);
        localStorage.setItem(id, newRow);
        //alert("Added!");
        //var test =  ;
        //alert(test);
    }
    else
    {
        //alert("Already exists!");
        getItOut(id);
    }
}


function getItOut(id)
{

    //alert("ingetitout");
    localStorage.removeItem(id);
    
}

function reloadPage()
{
    window.location.reload();
}


function selectUserTab(ct)
{
    //alert("Called me");
    
    
    if ( document.getElementById("usersTab").className.match(/(?:^|\s)active(?!\S)/))
    {
        //alert("pagesactive");
        document.getElementById("usersTab").className = document.getElementById("pagesTab").className.replace( /(?:^|\s)active(?!\S)/g , '' );
    }
    
    if ( document.getElementById("pagesTab").className.match(/(?:^|\s)active(?!\S)/))
    {
        //alert("pagesactive");
        document.getElementById("pagesTab").className = document.getElementById("pagesTab").className.replace( /(?:^|\s)active(?!\S)/g , '' );
    }
    
    if ( document.getElementById("eventsTab").className.match(/(?:^|\s)active(?!\S)/))
    {
        //alert("eventsactive");
        document.getElementById("eventsTab").className = document.getElementById("eventsTab").className.replace( /(?:^|\s)active(?!\S)/g , '' );
    }
    
    if ( document.getElementById("placesTab").className.match(/(?:^|\s)active(?!\S)/))
    {
        //alert("placesactive");
        document.getElementById("placesTab").className = document.getElementById("placesTab").className.replace( /(?:^|\s)active(?!\S)/g , '' );
    }
    
    if ( document.getElementById("groupsTab").className.match(/(?:^|\s)active(?!\S)/))
    {
        //alert("groupsactive");
        document.getElementById("groupsTab").className = document.getElementById("groupsTab").className.replace( /(?:^|\s)active(?!\S)/g , '' );
    }
    
    if ( document.getElementById("favsTab").className.match(/(?:^|\s)active(?!\S)/))
    {
        //alert("favsactive");
        document.getElementById("favsTab").className = document.getElementById("favsTab").className.replace( /(?:^|\s)active(?!\S)/g , '' );
    }
    if(ct=="user")
    {
        document.getElementById("usersTab").className = "active";
    }
    else if(ct=="place")
    {
        document.getElementById("placesTab").className = "active";
    }
    else if(ct=="group")
    {
        document.getElementById("groupsTab").className = "active";
    }
    else if(ct=="fav")
    {
        document.getElementById("favsTab").className = "active";
    }
    else if(ct=="event")
    {
        document.getElementById("eventsTab").className = "active";
    }
    else if(ct=="page")
    {
        document.getElementById("pagesTab").className = "active";
    }
    
    
}


function initTab(){
    
    document.getElementById("usersTab").className = "active";
}

var app = angular.module('myApp', ["ngAnimate", "ngRoute"])

.animation('.slide', function() {
           var NgHideClassName = 'ng-hide';
           return {
           beforeAddClass: function(element, className, done) {
           if(className === NgHideClassName) {
           jQuery(element).slideUp(done);
           }
           },
           removeClass: function(element, className, done) {
           if(className === NgHideClassName) {
           jQuery(element).hide().slideDown(done);
           }
           }
           }
           });

app.controller('myCtrl', function($scope, $http) {
               
               initTab();
               $scope.postsAndAlbums = true;
               $scope.favTable = true;
               $scope.noalbums = false;
               $scope.noposts = false;
               $scope.uresultTable = true;
               $scope.presultTable = true;
               $scope.eresultTable = true;
               $scope.plresultTable = true;
               $scope.gresultTable = true;
               
               $scope.mainBar = true;
               $scope.albumBar = true;
               $scope.postBar = true;
               
           
                            
               $scope.callIt = function(option) {
               
               if($scope.inputSearch==null)
               {
               
               $scope.postsAndAlbums = true;
               $scope.favTable = true;
               $scope.noalbums = false;
               $scope.noposts = false;
               $scope.uresultTable = true;
               $scope.presultTable = true;
               $scope.eresultTable = true;
               $scope.plresultTable = true;
               $scope.gresultTable = true;
               $scope.mainBar = true;
               $scope.albumBar = true;
               $scope.postBar = true;
               }
               else{
               
               currentTab=option;
               //alert(option);
               $scope.favTable = true;
               $scope.postsAndAlbums = true;
               $scope.noalbums = false;
               $scope.noposts = false;
               if(option=="user")
               {
               
               $scope.uresultTable = false;
               $scope.presultTable = true;
               $scope.eresultTable = true;
               $scope.plresultTable = true;
               $scope.gresultTable = true;

               
               }
               else if(option=="page")
               {
               
               $scope.uresultTable = true;
               $scope.presultTable = false;
               $scope.eresultTable = true;
               $scope.plresultTable = true;
               $scope.gresultTable = true;

               
               }
               else if(option=="event")
               {
               
               $scope.uresultTable = true;
               $scope.presultTable = true;
               $scope.eresultTable = false;
               $scope.plresultTable = true;
               $scope.gresultTable = true;

               
               }
               else if(option=="place")
               {
               
               $scope.uresultTable = true;
               $scope.presultTable = true;
               $scope.eresultTable = true;
               $scope.plresultTable = false;
               $scope.gresultTable = true;

               
               }
               else if(option=="group")
               {
               
               $scope.uresultTable = true;
               $scope.presultTable = true;
               $scope.eresultTable = true;
               $scope.plresultTable = true;
               $scope.gresultTable = false;

               
               }}
               
               }
               
               
               
               $scope.callItD = function() {
               option=currentTab;
               
               selectUserTab(currentTab);
               $scope.postsAndAlbums = true;
               $scope.favTable = true;
               $scope.noalbums = false;
               $scope.noposts = false;
               $scope.uresultTable = true;
               $scope.presultTable = true;
               $scope.eresultTable = true;
               $scope.plresultTable = true;
               $scope.gresultTable = true;
               
            
               if($scope.inputSearch==null)
               {
               //alert("Please enter a value");
               $(".form-control").tooltip('show');
               }
               else{
               $(".form-control").tooltip('hide');
               input=$scope.inputSearch;
               $scope.currentStatus = 0;
               $scope.mainBar = false;
               //console.log($scope.mainBar);
               $http({
                     method : "GET",
                     url : "myPhp.php",
                     params: { ip: input, type: "user", lat: lat, long: long, choice: "usual"}
                     }).then(function mySucces(uresponse) {
                             //console.log(uresponse.data);
                             
                      
                             if(uresponse.data.data=="")
                             {
                             alert("No data found.");
                             reloadPage();
                             }
                             else{
                             
                             $scope.utuples = uresponse.data.data;
                             //console.log(uresponse.data.data);
                             $scope.uresultTable = true;
                             $scope.postsAndAlbums = true;
                             $scope.favTable = true;
                             $scope.uprevBtn = true;
                             
                             

                             

                             //console.log(uresponse.data.paging.next);
                             
                             
                             if (typeof uresponse.data.paging.next !== 'undefined') {
                             $scope.unextBtn = false;
                             $scope.unPage = uresponse.data.paging.next;
                             }
                             //console.log("Ready1");
                             $scope.currentStatus = $scope.currentStatus + 20;
                             if($scope.currentStatus=="100")
                             {
                             //alert(currentTab);
                             if(currentTab=="user")
                             {
                             
                             $scope.uresultTable = false;
                             $scope.presultTable = true;
                             $scope.eresultTable = true;
                             $scope.plresultTable = true;
                             $scope.gresultTable = true;
                             
                             
                             }
                             else if(currentTab=="page")
                             {
                             
                             $scope.uresultTable = true;
                             $scope.presultTable = false;
                             $scope.eresultTable = true;
                             $scope.plresultTable = true;
                             $scope.gresultTable = true;
                             
                             
                             }
                             else if(currentTab=="event")
                             {
                             
                             $scope.uresultTable = true;
                             $scope.presultTable = true;
                             $scope.eresultTable = false;
                             $scope.plresultTable = true;
                             $scope.gresultTable = true;
                             
                             
                             }
                             else if(currentTab=="place")
                             {
                             
                             $scope.uresultTable = true;
                             $scope.presultTable = true;
                             $scope.eresultTable = true;
                             $scope.plresultTable = false;
                             $scope.gresultTable = true;
                             
                             
                             }
                             else if(currentTab=="group")
                             {
                             
                             $scope.uresultTable = true;
                             $scope.presultTable = true;
                             $scope.eresultTable = true;
                             $scope.plresultTable = true;
                             $scope.gresultTable = false;
                             
                             
                             }
                             else if(currentTab == "fav")
                             {
                             $scope.uresultTable = true;
                             $scope.presultTable = true;
                             $scope.eresultTable = true;
                             $scope.plresultTable = true;
                             $scope.gresultTable = true;
                             $scope.favTable = false;
                             
                             }
                             $scope.mainBar = true;
                             //console.log($scope.mainBar);
                             }}
                             
                             }, function myError(uresponse) {
                             //$scope.myWelcome = response.statusText;
                             
                             
                             });
               
               $http({
                     method : "GET",
                     url : "myPhp.php",
                     params: { ip: input, type: "page", lat: lat, long: long, choice: "usual"}
                     }).then(function mySucces(presponse) {
                             //console.log(response.data);
                             
                             if(presponse.data.data=="")
                             {
                             alert("No data found.");
                             reloadPage();
                             }
                             else{
                             $scope.ptuples = presponse.data.data;

                             $scope.postsAndAlbums = true;
                             $scope.favTable = true;
                             $scope.pprevBtn = true;
                             
                             
                             //console.log(presponse.data.paging.next);
                             
                             
                             if (typeof presponse.data.paging.next !== 'undefined') {
                             $scope.pnextBtn = false;
                             $scope.pnPage = presponse.data.paging.next;
                             }
                             //console.log("Ready2");
                             $scope.currentStatus = $scope.currentStatus + 20;
                             if($scope.currentStatus=="100")
                             {
                             //alert(currentTab);
                             if(currentTab=="user")
                             {
                             
                             $scope.uresultTable = false;
                             $scope.presultTable = true;
                             $scope.eresultTable = true;
                             $scope.plresultTable = true;
                             $scope.gresultTable = true;
                             
                             
                             }
                             else if(currentTab=="page")
                             {
                             
                             $scope.uresultTable = true;
                             $scope.presultTable = false;
                             $scope.eresultTable = true;
                             $scope.plresultTable = true;
                             $scope.gresultTable = true;
                             
                             
                             }
                             else if(currentTab=="event")
                             {
                             
                             $scope.uresultTable = true;
                             $scope.presultTable = true;
                             $scope.eresultTable = false;
                             $scope.plresultTable = true;
                             $scope.gresultTable = true;
                             
                             
                             }
                             else if(currentTab=="place")
                             {
                             
                             $scope.uresultTable = true;
                             $scope.presultTable = true;
                             $scope.eresultTable = true;
                             $scope.plresultTable = false;
                             $scope.gresultTable = true;
                             
                             
                             }
                             else if(currentTab=="group")
                             {
                             
                             $scope.uresultTable = true;
                             $scope.presultTable = true;
                             $scope.eresultTable = true;
                             $scope.plresultTable = true;
                             $scope.gresultTable = false;
                             
                             
                             }
                             else if(currentTab == "fav")
                             {
                             $scope.uresultTable = true;
                             $scope.presultTable = true;
                             $scope.eresultTable = true;
                             $scope.plresultTable = true;
                             $scope.gresultTable = true;
                             $scope.favTable = false;
                             
                             }
                             $scope.mainBar = true;
                             //console.log($scope.mainBar);
                             }}
                             
                             }, function myError(presponse) {
                             //$scope.myWelcome = response.statusText;
                             });
               
               $http({
                     method : "GET",
                     url : "myPhp.php",
                     params: { ip: input, type: "event", lat: lat, long: long, choice: "usual"}
                     }).then(function mySucces(eresponse) {
                             //console.log(response.data);
                             if(eresponse.data.data=="")
                             {
                             alert("No data found.");
                             reloadPage();
                             }
                             else{
                             $scope.etuples = eresponse.data.data;

                             $scope.postsAndAlbums = true;
                             $scope.favTable = true;
                             $scope.eprevBtn = true;
                             
                             
                             //console.log(eresponse.data.paging.next);
                             
                             
                             if (typeof eresponse.data.paging.next !== 'undefined') {
                             $scope.enextBtn = false;
                             $scope.enPage = eresponse.data.paging.next;
                             }
                             //console.log("Ready3");
                             $scope.currentStatus = $scope.currentStatus + 20;
                             if($scope.currentStatus=="100")
                             {
                             //alert(currentTab);
                             if(currentTab=="user")
                             {
                             
                             $scope.uresultTable = false;
                             $scope.presultTable = true;
                             $scope.eresultTable = true;
                             $scope.plresultTable = true;
                             $scope.gresultTable = true;
                             
                             
                             }
                             else if(currentTab=="page")
                             {
                             
                             $scope.uresultTable = true;
                             $scope.presultTable = false;
                             $scope.eresultTable = true;
                             $scope.plresultTable = true;
                             $scope.gresultTable = true;
                             
                             
                             }
                             else if(currentTab=="event")
                             {
                             
                             $scope.uresultTable = true;
                             $scope.presultTable = true;
                             $scope.eresultTable = false;
                             $scope.plresultTable = true;
                             $scope.gresultTable = true;
                             
                             
                             }
                             else if(currentTab=="place")
                             {
                             
                             $scope.uresultTable = true;
                             $scope.presultTable = true;
                             $scope.eresultTable = true;
                             $scope.plresultTable = false;
                             $scope.gresultTable = true;
                             
                             
                             }
                             else if(currentTab=="group")
                             {
                             
                             $scope.uresultTable = true;
                             $scope.presultTable = true;
                             $scope.eresultTable = true;
                             $scope.plresultTable = true;
                             $scope.gresultTable = false;
                             
                             
                             }
                             else if(currentTab == "fav")
                             {
                             $scope.uresultTable = true;
                             $scope.presultTable = true;
                             $scope.eresultTable = true;
                             $scope.plresultTable = true;
                             $scope.gresultTable = true;
                             $scope.favTable = false;
                             
                             }
                             $scope.mainBar = true;
                             //console.log($scope.mainBar);
                             }
                             }
                             }, function myError(eresponse) {
                             //$scope.myWelcome = response.statusText;
                             });
               
               $http({
                     method : "GET",
                     url : "myPhp.php",
                     params: { ip: input, type: "place", lat: lat, long: long, choice: "usual"}
                     }).then(function mySucces(plresponse) {
                             //console.log(response.data);
                             if(plresponse.data.data=="")
                             {
                             alert("No data found.");
                             reloadPage();
                             }
                             else{
                             $scope.pltuples = plresponse.data.data;
                             
                             $scope.postsAndAlbums = true;
                             $scope.favTable = true;
                             $scope.plprevBtn = true;
                             
                             
                             //console.log(plresponse.data.paging.next);
                             
                             
                             if (typeof plresponse.data.paging.next !== 'undefined') {
                             $scope.plnextBtn = false;
                             $scope.plnPage = plresponse.data.paging.next;
                             }
                             //console.log("Ready4");
                             $scope.currentStatus = $scope.currentStatus + 20;
                             if($scope.currentStatus=="100")
                             {
                             //alert(currentTab);
                             if(currentTab=="user")
                             {
                             
                             $scope.uresultTable = false;
                             $scope.presultTable = true;
                             $scope.eresultTable = true;
                             $scope.plresultTable = true;
                             $scope.gresultTable = true;
                             
                             
                             }
                             else if(currentTab=="page")
                             {
                             
                             $scope.uresultTable = true;
                             $scope.presultTable = false;
                             $scope.eresultTable = true;
                             $scope.plresultTable = true;
                             $scope.gresultTable = true;
                             
                             
                             }
                             else if(currentTab=="event")
                             {
                             
                             $scope.uresultTable = true;
                             $scope.presultTable = true;
                             $scope.eresultTable = false;
                             $scope.plresultTable = true;
                             $scope.gresultTable = true;
                             
                             
                             }
                             else if(currentTab=="place")
                             {
                             
                             $scope.uresultTable = true;
                             $scope.presultTable = true;
                             $scope.eresultTable = true;
                             $scope.plresultTable = false;
                             $scope.gresultTable = true;
                             
                             
                             }
                             else if(currentTab=="group")
                             {
                             
                             $scope.uresultTable = true;
                             $scope.presultTable = true;
                             $scope.eresultTable = true;
                             $scope.plresultTable = true;
                             $scope.gresultTable = false;
                             
                             
                             }
                             else if(currentTab == "fav")
                             {
                             $scope.uresultTable = true;
                             $scope.presultTable = true;
                             $scope.eresultTable = true;
                             $scope.plresultTable = true;
                             $scope.gresultTable = true;
                             $scope.favTable = false;
                             
                             }
                             $scope.mainBar = true;
                             //console.log($scope.mainBar);
                             }}
                             
                             }, function myError(plresponse) {
                             //$scope.myWelcome = response.statusText;
                             });
               
               $http({
                     method : "GET",
                     url : "myPhp.php",
                     params: { ip: input, type: "group", lat: lat, long: long, choice: "usual"}
                     }).then(function mySucces(gresponse) {
                             //console.log(response.data);
                             if(gresponse.data.data=="")
                             {
                             alert("No data found.");
                             reloadPage();
                             }
                             else{
                             $scope.gtuples = gresponse.data.data;
                             
                             $scope.postsAndAlbums = true;
                             $scope.favTable = true;
                             $scope.gprevBtn = true;
                             
                             
                             //console.log(gresponse.data.paging.next);
                             
                             
                             if (typeof gresponse.data.paging.next !== 'undefined') {
                             $scope.gnextBtn = false;
                             $scope.gnPage = gresponse.data.paging.next;
                             }
                             //console.log("Ready5");
                             $scope.currentStatus = $scope.currentStatus + 20;
                             if($scope.currentStatus=="100")
                             {
                             //alert(currentTab);
                             if(currentTab=="user")
                             {
                             
                             $scope.uresultTable = false;
                             $scope.presultTable = true;
                             $scope.eresultTable = true;
                             $scope.plresultTable = true;
                             $scope.gresultTable = true;
                             
                             
                             }
                             else if(currentTab=="page")
                             {
                             
                             $scope.uresultTable = true;
                             $scope.presultTable = false;
                             $scope.eresultTable = true;
                             $scope.plresultTable = true;
                             $scope.gresultTable = true;
                             
                             
                             }
                             else if(currentTab=="event")
                             {
                             
                             $scope.uresultTable = true;
                             $scope.presultTable = true;
                             $scope.eresultTable = false;
                             $scope.plresultTable = true;
                             $scope.gresultTable = true;
                             
                             
                             }
                             else if(currentTab=="place")
                             {
                             
                             $scope.uresultTable = true;
                             $scope.presultTable = true;
                             $scope.eresultTable = true;
                             $scope.plresultTable = false;
                             $scope.gresultTable = true;
                             
                             
                             }
                             else if(currentTab=="group")
                             {
                             
                             $scope.uresultTable = true;
                             $scope.presultTable = true;
                             $scope.eresultTable = true;
                             $scope.plresultTable = true;
                             $scope.gresultTable = false;
                             
                             
                             }
                             else if(currentTab == "fav")
                             {
                             $scope.uresultTable = true;
                             $scope.presultTable = true;
                             $scope.eresultTable = true;
                             $scope.plresultTable = true;
                             $scope.gresultTable = true;
                             $scope.favTable = false;
                             
                             }
                             $scope.mainBar = true;
                             //console.log($scope.mainBar);
                             }}
                             
                             }, function myError(gresponse) {
                             //$scope.myWelcome = response.statusText;
                             });
               }
               }
              
               
               $scope.notThere= function(id,op) {
               
               if (localStorage.getItem(id) === null)
               {
             
               return true;
               }
               else
               {
               //console.log(localStorage.getItem(id));
               //Present
               return false;
               }

               }
               
               
               $scope.there= function(id,op) {
               
               if (localStorage.getItem(id))
               {
               //Present
               //console.log(localStorage.getItem(id));
               return true;
               }
               else
               {
               
               return false;
               }
               
               }
               
               
        
               
               $scope.forDetails = function(id,name,url,tab) {
               //console.log(id);
               //console.log(currentTab);
               //console.log(input);
               
             
               
               $scope.uresultTable = true;
               $scope.presultTable = true;
               $scope.eresultTable = true;
               $scope.plresultTable = true;
               $scope.gresultTable = true;
               $scope.favTable = true;
               //alert(tab);
               
               
               $scope.aalbums = true;
               $scope.pposts = true;
               $scope.noalbums = false;
               $scope.noposts = false;
               
              
               $scope.postsAndAlbums = false;
               
             
               $scope.albumBar = false;
               $scope.postBar = false;
               $scope.currentStatusAlbum=0;
               $scope.currentStatusPost=0;
               
               
               $scope.currentStatusAlbum=$scope.currentStatusAlbum+50;
               $scope.currentStatusPost=$scope.currentStatusPost+50;
               $http({
                     method : "GET",
                     url : "myPhp.php",
                     params: { ip: input, type: currentTab, lat: lat, long: long, choice: "details", id:id}
                     }).then(function mySucces(response) {
                             //$scope.tuples = response.data;
                             //console.log(response.data.albums.data);
                             //console.log(response.data.albums.data);
                             //console.log(response.data.posts.data);
                             //$scope.resultTable = true;
                             

                             $scope.option = currentTab;
                             
                             if(typeof response.data.albums === 'undefined' && typeof response.data.posts !== 'undefined')
                             {
                             //alert("1");
                                $scope.aalbums = true;
                                $scope.noalbums = true;
                                $scope.albumBar = true;
                             $scope.tupps = response.data.posts.data;
                             $scope.tab=tab;
                             $scope.nameIt = name;
                             $scope.imgURL = url;
                             $scope.id = id;
                             $scope.currentStatusPost=$scope.currentStatusPost+50;
                             if($scope.currentStatusPost=="100")
                             {
                             
                             $scope.postBar = true;
                             $scope.pposts = false;
                             }
                             
                             }
                             
                             else if(typeof response.data.posts === 'undefined' && typeof response.data.albums !== 'undefined')
                             {
                             //alert("2");
                                $scope.pposts = true;
                                $scope.noposts = true;
                                $scope.postBar = true;
                             $scope.tups = response.data.albums.data;
                             $scope.tab=tab;
                             $scope.nameIt = name;
                             $scope.imgURL = url;
                             $scope.id = id;
                             $scope.currentStatusAlbum=$scope.currentStatusAlbum+50;
                             if($scope.currentStatusAlbum=="100")
                             {
                             
                             $scope.albumBar = true;
                             $scope.aalbums = false;
                             
                             }

                             
                             }
                             
                             else if(typeof response.data.posts === 'undefined' && typeof response.data.albums === 'undefined')
                             
                             {
                             //alert("3");
                             $scope.aalbums = true;
                             $scope.noalbums = true;
                             $scope.albumBar = true;
                             $scope.pposts = true;
                             $scope.noposts = true;
                             $scope.postBar = true;
                             
                             }
                             else{
                             //alert("4");
                             $scope.tups = response.data.albums.data;
                             $scope.tupps = response.data.posts.data;
                             $scope.tab=tab;
                             $scope.nameIt = name;
                             $scope.imgURL = url;
                             $scope.id = id;
                             $scope.currentStatusAlbum=$scope.currentStatusAlbum+50;
                             $scope.currentStatusPost=$scope.currentStatusPost+50;
                           
                             
                             if($scope.currentStatusAlbum=="100")
                             {
                            
                             $scope.albumBar = true;
                             $scope.aalbums = false;
                             
                             }
                             
                             if($scope.currentStatusPost=="100")
                             {
                             
                             $scope.postBar = true;
                             $scope.pposts = false;
                             }
                             }
                             //console.log(response.data.posts.data);
                            
                             
                             //console.log(response.data);
                           
                             }, function myError(response) {
                             //$scope.myWelcome = response.statusText;
                             });
               //console.log("Done");
               
               }

               
               
               $scope.goBack = function(option,tab) {
               //alert(option);
               //alert("In goback");
               //alert(tab);
        
               $scope.postsAndAlbums = true;
               $scope.favTable = true;
               
               if(tab=="f")
               {
               //alert("go back to favorites");
               $scope.uresultTable = true;
               $scope.presultTable = true;
               $scope.eresultTable = true;
               $scope.plresultTable = true;
               $scope.gresultTable = true;
               $scope.favTable = false;
               }
               else{
               if(option=="user")
               {
             
               $scope.uresultTable = false;
               $scope.presultTable = true;
               $scope.eresultTable = true;
               $scope.plresultTable = true;
               $scope.gresultTable = true;
               }
               else if(option=="page")
               {
               $scope.uresultTable = true;
               $scope.presultTable = false;
               $scope.eresultTable = true;
               $scope.plresultTable = true;
               $scope.gresultTable = true;
               }
               else if(option=="event")
               {
               $scope.uresultTable = true;
               $scope.presultTable = true;
               $scope.eresultTable = false;
               $scope.plresultTable = true;
               $scope.gresultTable = true;
               }
               else if(option=="place")
               {
               $scope.uresultTable = true;
               $scope.presultTable = true;
               $scope.eresultTable = true;
               $scope.plresultTable = false;
               $scope.gresultTable = true;
               }
               else if(option=="group")
               {
               $scope.uresultTable = true;
               $scope.presultTable = true;
               $scope.eresultTable = true;
               $scope.plresultTable = true;
               $scope.gresultTable = false;
               
               
               }}
              
               }
               
              
               
             
               
               $scope.favorite = function(name,url,id) {
               //alert("infavorite");
               letsGo(name,url,currentTab,id);
               }
               
               $scope.getItOutNow = function(id) {
               getItOut(id);
               
               if(localStorage.length==0)
               {
               $scope.favTable = true;
               $scope.postsAndAlbums = true;
               $scope.uresultTable = true;
               $scope.presultTable = true;
               $scope.eresultTable = true;
               $scope.plresultTable = true;
               $scope.gresultTable = true;
               
               }
               
               }
               
               $scope.showFavorite = function() {
               currentTab="fav";
               //alert(currentTab);
               if(localStorage.length==0)
               {
               $scope.favTable = true;
               $scope.postsAndAlbums = true;
               $scope.uresultTable = true;
               $scope.presultTable = true;
               $scope.eresultTable = true;
               $scope.plresultTable = true;
               $scope.gresultTable = true;

               }else{
               
               $scope.postsAndAlbums = true;
               $scope.favTable = false;
               
               
               $scope.uresultTable = true;
               $scope.presultTable = true;
               $scope.eresultTable = true;
               $scope.plresultTable = true;
               $scope.gresultTable = true;
               
               $scope.ls = localStorage;
               }
               }
               
              
               
               $scope.postToFb = function(imgURL,nameIt) {
               //alert("You want to post to Facebook");
               //alert(imgURL);
               //alert(nameIt);
               //var Your_App_ID = 151407148710046;
               
               
               FB.ui({
                     
                     app_id: '151407148710046',
                     method: 'feed',
                     link: window.location.href,
                     picture: imgURL,
                     name: nameIt,
                     caption: "FB SEARCH FROM USC CSCI571",
                     }, function(response){
                     if (response && !response.error_message)
                     {
                     alert("Posted Successfully");
                     }
                     else
                     {
                     alert("Not Posted");
                     }
                     });

               
               
               }
           
               
               
               $scope.upreviousPage = function(pPage) {
               //alert("previous page, please");
               //alert(pPage);
               
               $http({
                     method : "GET",
                     url : pPage
                     }).then(function mySucces(response) {
                             //console.log(response.data);
                             
                             $scope.utuples = response.data.data;
                             $scope.uresultTable = false;
                             $scope.postsAndAlbums = true;
                             $scope.favTable = true;
                             
                            
                             

                             //console.log(response.data.paging.next);
                             //console.log(response.data.paging.previous);
                             
                             if (typeof response.data.paging.next !== 'undefined') {
                             $scope.unextBtn = false;
                             $scope.unPage = response.data.paging.next;
                             }
                             else
                             {
                             $scope.unextBtn = true;
                             }
                             
                             if (typeof response.data.paging.previous !== 'undefined') {
                             $scope.uprevBtn = false;
                             $scope.upPage = response.data.paging.previous;
                             }
                             else
                             {
                             $scope.uprevBtn = true;
                             }

                             
                             
                             }, function myError(response) {
                             //$scope.myWelcome = response.statusText;
                             });

               
               }
               
               
               
               $scope.ppreviousPage = function(pPage) {
               //alert("previous page, please");
               //alert(pPage);
               
               $http({
                     method : "GET",
                     url : pPage
                     }).then(function mySucces(response) {
                             //console.log(response.data);
                             
                             $scope.ptuples = response.data.data;
                             $scope.presultTable = false;
                             $scope.postsAndAlbums = true;
                             $scope.favTable = true;
                             
                             
                             
                             
                             //console.log(response.data.paging.next);
                             //console.log(response.data.paging.previous);
                             
                             if (typeof response.data.paging.next !== 'undefined') {
                             $scope.pnextBtn = false;
                             $scope.pnPage = response.data.paging.next;
                             }
                             else
                             {
                             $scope.pnextBtn = true;
                             }
                             
                             if (typeof response.data.paging.previous !== 'undefined') {
                             $scope.pprevBtn = false;
                             $scope.ppPage = response.data.paging.previous;
                             }
                             else
                             {
                             $scope.pprevBtn = true;
                             }
                             
                             
                             
                             }, function myError(response) {
                             //$scope.myWelcome = response.statusText;
                             });
               
               
               }
               $scope.epreviousPage = function(pPage) {
               //alert("previous page, please");
               //alert(pPage);
               
               $http({
                     method : "GET",
                     url : pPage
                     }).then(function mySucces(response) {
                             //console.log(response.data);
                             
                             $scope.etuples = response.data.data;
                             $scope.eresultTable = false;
                             $scope.postsAndAlbums = true;
                             $scope.favTable = true;
                             
                             
                             
                             
                             //console.log(response.data.paging.next);
                             //console.log(response.data.paging.previous);
                             
                             if (typeof response.data.paging.next !== 'undefined') {
                             $scope.enextBtn = false;
                             $scope.enPage = response.data.paging.next;
                             }
                             else
                             {
                             $scope.enextBtn = true;
                             }
                             
                             if (typeof response.data.paging.previous !== 'undefined') {
                             $scope.eprevBtn = false;
                             $scope.epPage = response.data.paging.previous;
                             }
                             else
                             {
                             $scope.eprevBtn = true;
                             }
                             
                             
                             
                             }, function myError(response) {
                             //$scope.myWelcome = response.statusText;
                             });
               
               
               }
               
               $scope.plpreviousPage = function(pPage) {
               //alert("previous page, please");
               //alert(pPage);
               
               $http({
                     method : "GET",
                     url : pPage
                     }).then(function mySucces(response) {
                             //console.log(response.data);
                             
                             $scope.pltuples = response.data.data;
                             $scope.plresultTable = false;
                             $scope.postsAndAlbums = true;
                             $scope.favTable = true;
                             
                             
                             
                             
                             //console.log(response.data.paging.next);
                             //console.log(response.data.paging.previous);
                             
                             if (typeof response.data.paging.next !== 'undefined') {
                             $scope.plnextBtn = false;
                             $scope.plnPage = response.data.paging.next;
                             }
                             else
                             {
                             $scope.plnextBtn = true;
                             }
                             
                             if (typeof response.data.paging.previous !== 'undefined') {
                             $scope.plprevBtn = false;
                             $scope.plpPage = response.data.paging.previous;
                             }
                             else
                             {
                             $scope.plprevBtn = true;
                             }
                             
                             
                             
                             }, function myError(response) {
                             //$scope.myWelcome = response.statusText;
                             });
               
               
               }
               
               $scope.gpreviousPage = function(pPage) {
               //alert("previous page, please");
               //alert(pPage);
               
               $http({
                     method : "GET",
                     url : pPage
                     }).then(function mySucces(response) {
                             //console.log(response.data);
                             
                             $scope.gtuples = response.data.data;
                             $scope.gresultTable = false;
                             $scope.postsAndAlbums = true;
                             $scope.favTable = true;
                             
                             
                             
                             
                             //console.log(response.data.paging.next);
                             //console.log(response.data.paging.previous);
                             
                             if (typeof response.data.paging.next !== 'undefined') {
                             $scope.gnextBtn = false;
                             $scope.gnPage = response.data.paging.next;
                             }
                             else
                             {
                             $scope.gnextBtn = true;
                             }
                             
                             if (typeof response.data.paging.previous !== 'undefined') {
                             $scope.gprevBtn = false;
                             $scope.gpPage = response.data.paging.previous;
                             }
                             else
                             {
                             $scope.gprevBtn = true;
                             }
                             
                             
                             
                             }, function myError(response) {
                             //$scope.myWelcome = response.statusText;
                             });
               
               
               }
               
               
               
               
               $scope.unextPage = function(nPage) {
               //alert("next page, please");
               //alert(nPage);
               
               $http({
                     method : "GET",
                     url : nPage
                     }).then(function mySucces(response) {
                             //console.log(response.data);
                             if(response.data.data=="")
                             {
                             $scope.unextBtn = true;
                             alert("No more data!");
                             
                             }else{
                             $scope.utuples = response.data.data;
                             $scope.uresultTable = false;
                             $scope.postsAndAlbums = true;
                             $scope.favTable = true;
                             
                             
                             //console.log(response.data.paging.next);
                             //console.log(response.data.paging.previous);
                             
                             
                             
                             
                             if (typeof response.data.paging.next !== 'undefined') {
                             $scope.unextBtn = false;
                             $scope.unPage = response.data.paging.next;
                             }
                             else
                             {
                             $scope.unextBtn = true;
                             }
                             
                             if (typeof response.data.paging.previous !== 'undefined') {
                             $scope.uprevBtn = false;
                             $scope.upPage = response.data.paging.previous;
                             }
                             else
                             {
                             $scope.uprevBtn = true;
                             }
                             }
                             
                             
                             }, function myError(response) {
                             //$scope.myWelcome = response.statusText;
                             });
 
               
               
               }
               
               
               $scope.pnextPage = function(nPage) {
               //alert("next page, please");
               //alert(nPage);
               
               $http({
                     method : "GET",
                     url : nPage
                     }).then(function mySucces(response) {
                             //console.log(response.data);
                             if(response.data.data=="")
                             {
                             $scope.pnextBtn = true;
                             alert("No more data!");
                             
                             }else{
                             $scope.ptuples = response.data.data;
                             $scope.presultTable = false;
                             $scope.postsAndAlbums = true;
                             $scope.favTable = true;
                             
                             
                             //console.log(response.data.paging.next);
                             //console.log(response.data.paging.previous);
                             
                             
                             
                             
                             if (typeof response.data.paging.next !== 'undefined') {
                             $scope.pnextBtn = false;
                             $scope.pnPage = response.data.paging.next;
                             }
                             else
                             {
                             $scope.pnextBtn = true;
                             }
                             
                             if (typeof response.data.paging.previous !== 'undefined') {
                             $scope.pprevBtn = false;
                             $scope.ppPage = response.data.paging.previous;
                             }
                             else
                             {
                             $scope.pprevBtn = true;
                             }
                             
                             }
                             
                             }, function myError(response) {
                             //$scope.myWelcome = response.statusText;
                             });
               
               
               
               }
               
               
               $scope.enextPage = function(nPage) {
               //alert("next page, please");
               //alert(nPage);
               
               $http({
                     method : "GET",
                     url : nPage
                     }).then(function mySucces(response) {
                             //console.log(response.data);
                             if(response.data.data=="")
                             {
                             $scope.enextBtn = true;
                             alert("No more data!");
                             
                             }else{
                             $scope.etuples = response.data.data;
                             $scope.eresultTable = false;
                             $scope.postsAndAlbums = true;
                             $scope.favTable = true;
                             
                             
                             //console.log(response.data.paging.next);
                             //console.log(response.data.paging.previous);
                             
                             
                             
                             
                             if (typeof response.data.paging.next !== 'undefined') {
                             $scope.enextBtn = false;
                             $scope.enPage = response.data.paging.next;
                             }
                             else
                             {
                             $scope.enextBtn = true;
                             }
                             
                             if (typeof response.data.paging.previous !== 'undefined') {
                             $scope.eprevBtn = false;
                             $scope.epPage = response.data.paging.previous;
                             }
                             else
                             {
                             $scope.eprevBtn = true;
                             }
                             
                             }
                             
                             }, function myError(response) {
                             //$scope.myWelcome = response.statusText;
                             });
               
               
               
               }
               
               
               $scope.plnextPage = function(nPage) {
               //alert("next page, please");
               //alert(nPage);
               
               $http({
                     method : "GET",
                     url : nPage
                     }).then(function mySucces(response) {
                             //console.log(response.data);
                             if(response.data.data=="")
                             {
                             $scope.plnextBtn = true;
                             alert("No more data!");
                             
                             }else{
                             $scope.pltuples = response.data.data;
                             $scope.plresultTable = false;
                             $scope.postsAndAlbums = true;
                             $scope.favTable = true;
                             
                             
                             //console.log(response.data.paging.next);
                             //console.log(response.data.paging.previous);
                             
                             
                             
                             
                             if (typeof response.data.paging.next !== 'undefined') {
                             $scope.plnextBtn = false;
                             $scope.plnPage = response.data.paging.next;
                             }
                             else
                             {
                             $scope.plnextBtn = true;
                             }
                             
                             if (typeof response.data.paging.previous !== 'undefined') {
                             $scope.plprevBtn = false;
                             $scope.plpPage = response.data.paging.previous;
                             }
                             else
                             {
                             $scope.plprevBtn = true;
                             }
                             
                             }
                             
                             }, function myError(response) {
                             //$scope.myWelcome = response.statusText;
                             });
               
               
               
               }
               
               
               $scope.gnextPage = function(nPage) {
               //alert("next page, please");
               //alert(nPage);
               
               $http({
                     method : "GET",
                     url : nPage
                     }).then(function mySucces(response) {
                             //console.log(response.data);
                             if(response.data.data=="")
                             {
                             $scope.gnextBtn = true;
                             alert("No more data!");
                             
                             }else{
                             $scope.gtuples = response.data.data;
                             $scope.gresultTable = false;
                             $scope.postsAndAlbums = true;
                             $scope.favTable = true;
                             
                             
                             //console.log(response.data.paging.next);
                             //console.log(response.data.paging.previous);

                             
                             if (typeof response.data.paging.next !== 'undefined') {
                             $scope.gnextBtn = false;
                             $scope.gnPage = response.data.paging.next;
                             }
                             else
                             {
                             $scope.gnextBtn = true;
                             }
                             
                             if (typeof response.data.paging.previous !== 'undefined') {
                             $scope.gprevBtn = false;
                             $scope.gpPage = response.data.paging.previous;
                             }
                             else
                             {
                             $scope.gprevBtn = true;
                             }
                             
                             }
                             
                             }, function myError(response) {
                             //$scope.myWelcome = response.statusText;
                             });
               
               
               
               }
               

               
               
               });

